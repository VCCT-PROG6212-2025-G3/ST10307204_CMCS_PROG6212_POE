using System.Text;
using CMCS_PROG6212_POE.Controllers;
using CMCS_PROG6212_POE.Data;
using CMCS_PROG6212_POE.Interfaces;
using CMCS_PROG6212_POE.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Moq;

namespace CMCS_PROG6212_POE.Tests1
{
    public class LecturerControllerTests1
    {
        private readonly LecturerController _controller;
        private readonly Mock<IDataStore> _mockDataStore;
        private readonly Mock<ITempDataDictionary> _mockTempData;
        private readonly Mock<ITempDataProvider> _mockTempDataProvider;

        public LecturerControllerTests1()
        {
            // Mock DataStore
            _mockDataStore = new Mock<IDataStore>();
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel>());

            // Mock TempData and provider
            _mockTempData = new Mock<ITempDataDictionary>();
            _mockTempDataProvider = new Mock<ITempDataProvider>();

            // Create HttpContext and ControllerContext
            var httpContext = new DefaultHttpContext();
            var tempData = new TempDataDictionary(httpContext, _mockTempDataProvider.Object);
            httpContext.Items["TempData"] = _mockTempData.Object;

            var controllerContext = new ControllerContext { HttpContext = httpContext };

            // Create controller and attach TempData mock
            _controller = new LecturerController(_mockDataStore.Object)
            {
                ControllerContext = controllerContext,
                TempData = _mockTempData.Object
            };
        }

        [Fact]
        public void SubmitClaim_ValidModel_ReturnsSuccess()
        {
            // Arrange
            var model = new ClaimModel
            {
                Lecturer = new LecturerModel
                {
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john@example.com"
                },
                HoursWorked = 40,
                HourlyRate = 25.0m,
                Approval = new ApprovalModel()
            };

            // Act
            var result = _controller.SubmitClaim(model) as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Index", result.ActionName);
            _mockDataStore.Verify(ds => ds.AddClaim(It.IsAny<ClaimModel>()), Times.Once());
            _mockTempData.VerifySet(td => td["SuccessMessage"] = It.Is<string>(s => s.Contains("submitted")), Times.Once());
        }

        [Fact]
        public void UploadDocuments_ValidFiles_ReturnsSuccess()
        {
            // Arrange
            var claim = new ClaimModel
            {
                ClaimId = 1,
                Status = "Pending",
                Documents = new List<DocumentModel>(),
                Approval = new ApprovalModel()
            };

            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel> { claim });

            var files = new List<IFormFile>
            {
                new FormFile(new MemoryStream(Encoding.UTF8.GetBytes("Test")), 0, 1024, "file", "test.pdf")
            };

            // Act
            var result = _controller.UploadDocuments(1, files) as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("UploadDocuments", result.ActionName);
            Assert.Single(claim.Documents);
            _mockTempData.VerifySet(td => td["SuccessMessage"] = It.Is<string>(s => s.Contains("uploaded")), Times.Once());
        }
    }
}