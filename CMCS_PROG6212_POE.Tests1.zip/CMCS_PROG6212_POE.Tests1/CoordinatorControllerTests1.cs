﻿using CMCS_PROG6212_POE.Controllers;
using CMCS_PROG6212_POE.Interfaces;
using CMCS_PROG6212_POE.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace CMCS_PROG6212_POE.Tests1
{

    public class CoordinatorControllerTests1
    {
        private readonly CoordinatorController _controller;
        private readonly Mock<IDataStore> _mockDataStore;
        private readonly Mock<ITempDataDictionary> _mockTempData;
        private readonly Mock<ITempDataProvider> _mockTempDataProvider;

        public CoordinatorControllerTests1()
        {
            _mockDataStore = new Mock<IDataStore>();
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel>());
            _mockTempData = new Mock<ITempDataDictionary>();
            _mockTempDataProvider = new Mock<ITempDataProvider>();
            var httpContext = new DefaultHttpContext();
            var tempData = new TempDataDictionary(httpContext, _mockTempDataProvider.Object);
            httpContext.Items["TempData"] = _mockTempData.Object;
            var controllerContext = new ControllerContext { HttpContext = httpContext };
            _controller = new CoordinatorController(_mockDataStore.Object)
            {
                ControllerContext = controllerContext,
                TempData = _mockTempData.Object
            };
        }

        [Fact]
        public void Index_VerifyClaim_UpdatesStatus()
        {
            // Arrange
            var claim = new ClaimModel
            {
                ClaimId = 1,
                Status = "Pending",
                Approval = new ApprovalModel() // Initialize Approval
            };
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel> { claim });

            // Act
            var result = _controller.Index(1, "Verify") as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Index", result.ActionName);
            Assert.Equal("Verified", claim.Status);
            _mockTempData.VerifySet(td => td["SuccessMessage"] = It.Is<string>(s => s.Contains("verified")), Times.Once());
        }
    }
}
