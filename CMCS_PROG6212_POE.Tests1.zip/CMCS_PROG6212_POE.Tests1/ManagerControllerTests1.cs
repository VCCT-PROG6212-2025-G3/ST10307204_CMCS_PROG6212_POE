﻿

using System.IO;
    using CMCS_PROG6212_POE.Controllers;
    using CMCS_PROG6212_POE.Interfaces;
    using CMCS_PROG6212_POE.Models;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.ViewFeatures;
    using Moq;
   using System.Security.Cryptography;
   using System.Text;


namespace CMCS_PROG6212_POE.Tests1
{

    public class ManagerControllerTests1
    {
        private readonly ManagerController _controller;
        private readonly Mock<IDataStore> _mockDataStore;
        private readonly Mock<ITempDataDictionary> _mockTempData;
        private readonly Mock<ITempDataProvider> _mockTempDataProvider;

        public ManagerControllerTests1()
        {
            _mockDataStore = new Mock<IDataStore>();
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel>());
            _mockTempData = new Mock<ITempDataDictionary>();
            _mockTempDataProvider = new Mock<ITempDataProvider>();
            var httpContext = new DefaultHttpContext();
            var tempData = new TempDataDictionary(httpContext, _mockTempDataProvider.Object);
            httpContext.Items["TempData"] = _mockTempData.Object;
            var controllerContext = new ControllerContext { HttpContext = httpContext };
            _controller = new ManagerController(_mockDataStore.Object)
            {
                ControllerContext = controllerContext,
                TempData = _mockTempData.Object
            };
        }

        [Fact]
        public void Index_ApproveClaim_UpdatesStatus()
        {
            // Arrange
            var claim = new ClaimModel
            {
                ClaimId = 1,
                Status = "Verified",
                Approval = new ApprovalModel() // Initialize Approval to prevent NullReferenceException
            };
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel> { claim });

            // Act
            var result = _controller.Index(1, "Approve") as RedirectToActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Index", result.ActionName);
            Assert.Equal("Approved", claim.Status);
            Assert.NotNull(claim.Approval.ManagerId); // Verify ManagerId is set
            Assert.NotNull(claim.Approval.ApprovalDate); // Verify ApprovalDate is set
            _mockTempData.VerifySet(td => td["SuccessMessage"] = It.Is<string>(s => s.Contains("approved")), Times.Once());
        }

        [Fact]
        public void GetDocument_ValidRequest_ReturnsFile()
        {
            // Arrange
            var claim = new ClaimModel
            {
                ClaimId = 1,
                Status = "Verified",
                Documents = new List<DocumentModel>
            {
                new DocumentModel { FileName = "test.pdf", FilePath = "encrypted_123.pdf", FileSize = 1024 }
            },
                Approval = new ApprovalModel() // Initialize Approval
            };
            _mockDataStore.Setup(ds => ds.Claims).Returns(new List<ClaimModel> { claim });
            var filePath = Path.Combine(_controller._uploadPath, "encrypted_123.pdf");
            Directory.CreateDirectory(Path.GetDirectoryName(filePath));
            var originalBytes = new byte[1024];
            new Random().NextBytes(originalBytes);
            var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes("16-char-key-1234");
            aes.IV = new byte[16];
            using (var ms = new MemoryStream())
            using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
            {
                cs.Write(originalBytes, 0, originalBytes.Length);
                cs.Close();
                System.IO.File.WriteAllBytes(filePath, ms.ToArray());
            }

            // Act
            var result = _controller.GetDocument(1, "test.pdf") as FileContentResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal("application/pdf", result.ContentType);
            Assert.Equal("test.pdf", result.FileDownloadName);
            Assert.Equal(1024, result.FileContents.Length);
        }
    }
}